# Rafeek / رفيق — Brand identity exploration

**Recommendation:** Concept 02 — **The Daily Thread**.  
**Brand line:** A companion in every moment of care.  
**Arabic line:** رفيقك في تفاصيل الرعاية

This exploration is based on the existing `alaa157/caregiver-daily-notes` product codebase. The application is a bilingual care-support product for recording structured daily observations, reviewing a person’s history, creating AI-assisted summaries, and reviewing suggested care plans. The implementation uses a restrained warm-neutral interface, rounded bordered surfaces, compact functional components, and explicit evidence/uncertainty treatments.

## Product references inspected

- `README.md` — product scope, workflows, append-only notes, AI grounding and safety boundaries.
- `web/README.md` and `web/HANDOFF.md` — React/TypeScript web implementation and bilingual/RTL test conventions.
- `docs/design-system/DESIGN-STYLE.md` and `docs/design-system/tokens.css` — design personality, spacing, shapes, colors and semantic state roles.
- `web/src/styles/base.css`, `web/src/components/AppShell.css`, and feature styles — web shell, cards, buttons, typography and page structure.
- `web/src/features/overview/`, `notes/`, `summary/`, `plans/` — the actual care-recipient overview, note, summary and plan workflows.
- `android/app/src/main/java/com/caregiver/mobile/core/theme/` — Android color and typography conventions.

No production UI files were changed. The assets are isolated under `brand/rafeek/`.

## Four concepts

### 01 — The Beside
Two complementary, organic forms create a shared centre. It communicates presence and mutual support without depicting people or using a heart/hand icon. Warmest direction; may read as petals without the wordmark.

### 02 — The Daily Thread (recommended)
A continuous curved line moves through three moments. It expresses the journey from observation to context to understanding. It is the closest metaphor for the product’s real workflow, animates naturally, and remains legible as a small app mark. Keep it curved so it does not become a chart.

### 03 — The Gather
Four rounded arc fragments build one larger form around a shared centre. It represents separate notes becoming a fuller picture. Strong in patterns and product surfaces; slightly more abstract and less intimate.

### 04 — The Rafeek R
A custom rounded R is built from vector strokes with an outward-returning leg. It is the most typographic and timeless route. The Latin initial does not directly translate to Arabic, so the Arabic wordmark must remain an equal standalone lockup.

## Selected identity

- **Primary mark:** The Daily Thread (three points connected by one rounded continuous curve).
- **Primary Latin:** DM Sans, 600–700, gentle negative tracking.
- **Primary Arabic:** Noto Sans Arabic, 600–700, natural letterforms and RTL direction.
- **Android compatibility:** the existing app’s bundled IBM Plex Sans Arabic is suitable for the native product UI and already supports Latin + Arabic.
- **Primary brand colour:** Deep Pine `#285B45`.
- **Product accent:** Care Teal `#0E6B66`.
- **Human accent:** Warm Clay `#C77F68`. It is decorative; use dark ink, not white, on this fill.

The existing web green (`#285B45`) and Android caregiver teal (`#0E6B66`) are deliberately reconciled as distinct but related roles: brand/identity and product interaction. This is a proposed identity system; it does not silently rewrite application theme tokens.

## Colour contrast

Ratios are calculated with WCAG 2.1 relative luminance:

- Deep Pine on Paper: **7.51:1** (AA/AAA for normal text).
- White on Deep Pine: **7.86:1** (AA/AAA).
- Care Teal on Paper: **6.06:1** (AA/AAA).
- Quiet Text on Paper: **5.56:1** (AA).
- Near-black `#111111` on Warm Clay: **5.99:1** (AA for normal text).
- Forest Ink `#213B32` on Warm Clay: **3.84:1**; white on Warm Clay: **3.15:1** (neither meets AA for normal text). Keep Warm Clay decorative or use near-black on it.

Semantic success, warning, error and info colours retain the inspected application roles and are not repurposed as brand accents.

## Palette alternatives

**A — Olive Grove (selected):** `#285B45`, `#0E6B66`, `#C77F68`, `#FAFAF6`, `#F7F6F3`. Closest to the existing web and Android product language.

**B — Tide & Terracotta:** `#3E5962`, `#263E48`, `#A85E43`, `#F8F2EA`. A more mineral/coastal option, intentionally more distinct from the current green family.

## Files

- `brand-sheet.html` + `brand-sheet.css` — responsive, navigable brand presentation with print styles.
- `concepts/concept-01` … `concept-04` — independent vector concept boards and logo variants.
- `selected/` — recommended logo system, icon, favicon and mono/black/white variants.
- `tokens/` — color, typography and brand tokens for reference.
- `brand-sheet-assets/` — supporting pattern artwork.
- `exports/` — transparent high-resolution logo PNGs, a 1024px app-icon PNG, small-size QA icons, the 13-page print-ready PDF, and a PNG overview montage of the PDF pages.

Each concept folder contains `concept.svg`, `concept-preview.png`, `symbol.svg`, `logo-horizontal-en.svg`, `logo-horizontal-ar.svg`, `logo-horizontal-bilingual.svg`, `logo-stacked.svg`, `app-icon.svg`, `monochrome.svg`, `logo-black.svg`, and `logo-white.svg`. SVGs contain editable path/shape geometry and live text, not embedded screenshots.

## Arabic / RTL notes

Arabic logo lockups are converted to shaped vector outlines from Noto Sans Arabic, with the word set and connected naturally in the correct RTL order. They remain legible across SVG renderers without depending on runtime font shaping. Arabic samples in the HTML use `lang="ar"` and `dir="rtl"`. The brand sheet references the repository’s DM Sans and Noto Sans Arabic web families (and recognises the Android IBM Plex Sans Arabic pairing); no font files are redistributed.

## Usage limits and product integration

This work is an identity exploration and brand presentation only. It does not change runtime application UI, Android launcher resources, website branding, theme settings, or production copy. The UI examples are designed mockups based on the inspected component conventions and use synthetic names/observations. They are not screenshots of a running production system. Trademark, domain and legal clearance have not been performed.

## Viewing / printing

Open `brand-sheet.html` in a browser. Its dedicated print stylesheet keeps the major sections together and adapts product and mockup layouts for A4 output. A pre-rendered 13-page A4 PDF is included at `exports/brand-sheet.pdf`; `exports/brand-sheet.png` is a thumbnail overview of the pages. The HTML layout is responsive at desktop and phone widths.
